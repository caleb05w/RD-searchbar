
  # Search Bar with Filter

  This is a code bundle for Search Bar with Filter. The original project is available at https://www.figma.com/design/K9W5OVJ7yAwV0pKFyGAR2K/Search-Bar-with-Filter.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  